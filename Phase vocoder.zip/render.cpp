/*
 ____  _____ _        _    
| __ )| ____| |      / \   
|  _ \|  _| | |     / _ \  
| |_) | |___| |___ / ___ \ 
|____/|_____|_____/_/   \_\

http://bela.io

C++ Real-Time Audio Programming with Bela - Lecture 20: Phase vocoder, part 3
fft-pitchshift: change the pitch of a sound without changing its timing using FFTs
*/

#include <Bela.h>
#include <libraries/Fft/Fft.h>
#include <libraries/Scope/Scope.h>
#include <libraries/Gui/Gui.h>
#include <libraries/GuiController/GuiController.h>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>
#include "MonoFilePlayer.h"

// Constants that define the program behaviour
// const unsigned int kTestsPerSecond = 4;			// How many tests to run per second
// const float kPulseLength = .02;					// Length of the output pulse
// const float kInputLoThreshold = 0.05;			// Input thresholds: look for an edge
// const float kInputHiThreshold = 0.15;			// from below the "lo" to above the "hi"

// // Global variables
// float gLastInput = 0;							// Previous value of the audio input
// unsigned int gTestInterval = 0;					// Samples between successive tests
// unsigned int gPulseLength = 0;					// How long is the pulse in samples?
// unsigned int gTestCounter = 0;					// How many samples since the last test?
// bool gInTest = false;							// Are we running a test?
// bool gInputAboveThreshold = false;				// Is the input high or low?

// FFT-related variables
Fft gFft;							// FFT processing object
const int gFftSize = 1024;			// FFT window size in samples
int gHopSize = 256;			// How often we calculate a window
float gScaleFactor = 0.5;			// How much to scale the output, based on window type and overlap
float gPitchShift = 1.0;			// Ratio of output to input frequency

// Circular buffer and pointer for assembling a window of samples
const int gBufferSize = 16384;
std::vector<float> gInputBuffer;
int gInputBufferPointer = 0;
int gHopCounter = 0;

// Circular buffer for collecting the output of the overlap-add process
std::vector<float> gOutputBuffer;

// Start the write pointer ahead of the read pointer by at least window + hop, with some margin
int gOutputBufferWritePointer = gFftSize + gHopSize;
int gOutputBufferReadPointer = 0;

// Buffer to hold the windows for FFT analysis and synthesis
std::vector<float> gAnalysisWindowBuffer;
std::vector<float> gSynthesisWindowBuffer;

// Thread for FFT processing
AuxiliaryTask gFftTask;
int gCachedInputBufferPointer = 0;
int koji = 0;

void process_fft_background(void *);

// Bela oscilloscope
Scope gScope;

// Browser-based GUI to adjust parameters
Gui gGui;
GuiController gGuiController;

// GUI slider indices
unsigned int gPitchShiftSliderIdx;
unsigned int gHopSizeSliderIdx;
unsigned int gEffectSliderIdx;

void recalculate_window(unsigned int length)
{
	// Check for running off the end of the buffer
	if(length > gAnalysisWindowBuffer.size())
		length = gAnalysisWindowBuffer.size();
	if(length > gSynthesisWindowBuffer.size())
		length = gSynthesisWindowBuffer.size();
		
	for(int n = 0; n < length; n++){
		// Hann window, split across analysis and synthesis window
		gAnalysisWindowBuffer[n] = 0.5f * (1.0f - cosf(2.0 * M_PI * n / (float)(length-1)));
		gSynthesisWindowBuffer[n] = gAnalysisWindowBuffer[n];
	}
}

bool setup(BelaContext *context, void *userData)
{
	// Set up the FFT and its buffers
	gFft.setup(gFftSize);
	gInputBuffer.resize(gBufferSize);
	gOutputBuffer.resize(gBufferSize);
	
	// Calculate the window
	gAnalysisWindowBuffer.resize(gFftSize);
	gSynthesisWindowBuffer.resize(gFftSize);
	recalculate_window(gFftSize);
	
	// Initialise the number of samples between successive pulses
	// and the length of the pulse
	// gTestInterval = context->audioSampleRate / kTestsPerSecond;
	// gPulseLength = context->audioSampleRate * kPulseLength;
	
	// Initialise the oscilloscope
	gScope.setup(2, context->audioSampleRate);
	
	// Set up the GUI
	gGui.setup(context->projectName);
	gGuiController.setup(&gGui, "0 = Pitch Shift, 1 = whisperisation, 2 = robotisation");	
	
	// Setup GUI sliders
    gPitchShiftSliderIdx = gGuiController.addSlider("Shift (semitones)", 0, -24, 24, 0.1);
    gHopSizeSliderIdx = gGuiController.addSlider("Hop Size (256)", 256, 64, 1024, 1);
    gEffectSliderIdx = gGuiController.addSlider("Effect", 0, 0, 2, 1);
	
	// Set up the thread for the FFT
	gFftTask = Bela_createAuxiliaryTask(process_fft_background, 50, "bela-process-fft");

	return true;
}

// Wrap the phase to the range -pi to pi
float wrapPhase(float phaseIn)
{
    if (phaseIn >= 0)
        return fmodf(phaseIn + M_PI, 2.0 * M_PI) - M_PI;
    else
        return fmodf(phaseIn - M_PI, -2.0 * M_PI) + M_PI;	
}

// This function handles the FFT processing in this example once the buffer has
// been assembled.

void process_fft(std::vector<float> const& inBuffer, unsigned int inPointer, std::vector<float>& outBuffer, unsigned int outPointer)
{
	if (koji == 0){
		static std::vector<float> unwrappedBuffer(gFftSize);	// Container to hold the unwrapped time-domain values
		
		static std::vector<float> lastInputPhases(gFftSize);	// Hold the phases from the previous hop of input signal
		static std::vector<float> lastOutputPhases(gFftSize);	// and output (synthesised) signal
		
		// These containers hold the converted representation from magnitude-phase
		// into magnitude-frequency, used for pitch shifting
		static std::vector<float> analysisMagnitudes(gFftSize / 2 + 1);
		static std::vector<float> analysisFrequencies(gFftSize / 2 + 1);
		static std::vector<float> synthesisMagnitudes(gFftSize / 2 + 1);
		static std::vector<float> synthesisFrequencies(gFftSize / 2 + 1);
		
		// Copy buffer into FFT input
		for(int n = 0; n < gFftSize; n++) {
			// Use modulo arithmetic to calculate the circular buffer index
			int circularBufferIndex = (inPointer + n - gFftSize + gBufferSize) % gBufferSize;
			unwrappedBuffer[n] = inBuffer[circularBufferIndex] * gAnalysisWindowBuffer[n];
		}
		
		// Process the FFT based on the time domain input
		gFft.fft(unwrappedBuffer);
		// Copy the lower half of the FFT bins to a buffer
	    std::vector<float> fftCurrentOut(gFftSize / 2);
	    for (int n = 0; n < gFftSize / 2; n++) {
	        fftCurrentOut[n] = gFft.fda(n);
	    }
			
		// Analyse the lower half of the spectrum. The upper half is just
		// the complex conjugate and does not contain any unique information
		for(int n = 0; n <= gFftSize/2; n++) {
			// Turn real and imaginary components into amplitude and phase
			float amplitude = gFft.fda(n);
			float phase = atan2f(gFft.fdi(n), gFft.fdr(n));
			
			// Calculate the phase difference in this bin between the last
			// hop and this one, which will indirectly give us the exact frequency
			float phaseDiff = phase - lastInputPhases[n];
			
			// Subtract the amount of phase increment we'd expect to see based
			// on the centre frequency of this bin (2*pi*n/gFftSize) for this
			// hop size, then wrap to the range -pi to pi
			float binCentreFrequency = 2.0 * M_PI * (float)n / (float)gFftSize;
			phaseDiff = wrapPhase(phaseDiff - binCentreFrequency * gHopSize);
			
			// Find deviation in (fractional) number of bins from the centre frequency
			float binDeviation = phaseDiff * (float)gFftSize / (float)gHopSize / (2.0 * M_PI);
			
			// Add the original bin number to get the fractional bin where this partial belongs
			analysisFrequencies[n] = (float)n + binDeviation;
			
			// Save the magnitude for later and for the GUI
			analysisMagnitudes[n] = amplitude;
			
			// Save the phase for next hop
			lastInputPhases[n] = phase;
		}	
	
		// Zero out the synthesis bins, ready for new data
		for(int n = 0; n <= gFftSize/2; n++) {
			synthesisMagnitudes[n] = synthesisFrequencies[n] = 0;
		}
		
		// Handle the pitch shift, storing frequencies into new bins
		for(int n = 0; n <= gFftSize/2; n++) {
			// TODO: find the nearest bin to the shifted frequency
			int newBin = floorf(n * gPitchShift + 0.5);
			
			// Ignore any bins that have shifted above Nyquist
			if(newBin <= gFftSize / 2) {
				synthesisMagnitudes[newBin] += analysisMagnitudes[n];
				
				// TODO: scale the frequency by the pitch shift ratio
				synthesisFrequencies[newBin] = analysisFrequencies[n] * gPitchShift;
			}
		}
			
		// Synthesise frequencies into new magnitude and phase values for FFT bins
		for(int n = 0; n <= gFftSize / 2; n++) {
			float amplitude = synthesisMagnitudes[n];
			
			// TODO: Get the fractional offset from the bin centre frequency
			float binDeviation = synthesisFrequencies[n] - n;
			// TODO: Multiply to get back to a phase value
			float phaseDiff = binDeviation * 2.0 * M_PI * (float)gHopSize / (float)gFftSize;
			// TODO: Add the expected phase increment based on the bin centre frequency
			float binCentreFrequency = 2.0 * M_PI * float(n) / (float)gFftSize;
			phaseDiff += binCentreFrequency * gHopSize;
			// TODO: Advance the phase from the previous hop
			float outPhase = wrapPhase(lastOutputPhases[n] + phaseDiff);
			// TODO: Now convert magnitude and phase back to real and imaginary components
			gFft.fdr(n) = amplitude * cosf(outPhase);	// change me
			gFft.fdi(n) = amplitude * sinf(outPhase);	// change me
			
			// Also store the complex conjugate in the upper half of the spectrum
			if(n > 0 && n < gFftSize / 2) {
				gFft.fdr(gFftSize - n) = gFft.fdr(n);
				gFft.fdi(gFftSize - n) = -gFft.fdi(n);
			}
			
			// TODO: Save the phase for the next hop
			lastOutputPhases[n] = outPhase;
		}
	}
	else if (koji == 1){
		static std::vector<float> unwrappedBuffer(gFftSize);	// Container to hold the unwrapped values
	
		// Copy buffer into FFT input
		for(int n = 0; n < gFftSize; n++) {
			// Use modulo arithmetic to calculate the circular buffer index
			int circularBufferIndex = (inPointer + n - gFftSize + gBufferSize) % gBufferSize;
			unwrappedBuffer[n] = inBuffer[circularBufferIndex] * gAnalysisWindowBuffer[n];
		}
		
		// Process the FFT based on the time domain input
		gFft.fft(unwrappedBuffer);
		
		// Copy the lower half of the FFT bins to a buffer
	    std::vector<float> fftCurrentOut(gFftSize / 2);
	    for (int n = 0; n < gFftSize / 2; n++) {
	        fftCurrentOut[n] = gFft.fda(n);
	    }
			
		// Whisperise the output
		for(int n = 0; n < gFftSize; n++){
			float amplitude = gFft.fda(n);
			float phase = 2.0 * M_PI * (float)rand() / (float)RAND_MAX;
			gFft.fdr(n) = amplitude * cosf_neon(phase);
			gFft.fdi(n) = amplitude * sinf_neon(phase);
		}
	}
	else if (koji == 2){
		static std::vector<float> unwrappedBuffer(gFftSize);	// Container to hold the unwrapped values
	
		// Copy buffer into FFT input
		for(int n = 0; n < gFftSize; n++) {
			// Use modulo arithmetic to calculate the circular buffer index
			int circularBufferIndex = (inPointer + n - gFftSize + gBufferSize) % gBufferSize;
			unwrappedBuffer[n] = inBuffer[circularBufferIndex] * gAnalysisWindowBuffer[n];
		}
		
		// Process the FFT based on the time domain input
		gFft.fft(unwrappedBuffer);

		// Copy the lower half of the FFT bins to a buffer
	    std::vector<float> fftCurrentOut(gFftSize / 2);
	    for (int n = 0; n < gFftSize / 2; n++) {
	        fftCurrentOut[n] = gFft.fda(n);
	    }

		// Robotise the output
		for(int n = 0; n < gFftSize; n++) {
		 	float amplitude = gFft.fda(n);
			gFft.fdr(n) = amplitude;
			gFft.fdi(n) = 0;
		}
	}
	// Run the inverse FFT
	gFft.ifft();
	
	// Add timeDomainOut into the output buffer
	for(int n = 0; n < gFftSize; n++) {
		int circularBufferIndex = (outPointer + n - gFftSize + gBufferSize) % gBufferSize;
		outBuffer[circularBufferIndex] += gFft.td(n) * gSynthesisWindowBuffer[n];
	}
}

// This function runs in an auxiliary task on Bela, calling process_fft
void process_fft_background(void *)
{
	process_fft(gInputBuffer, gCachedInputBufferPointer, gOutputBuffer, gOutputBufferWritePointer);

	// Update the output buffer write pointer to start at the next hop
	gOutputBufferWritePointer = (gOutputBufferWritePointer + gHopSize) % gBufferSize;
}

void render(BelaContext *context, void *userData)
{
	// Get the pitch shift in semitones from the GUI slider and convert to ratio
	float pitchShiftSemitones = gGuiController.getSliderValue(0);
	gPitchShift = powf(2.0, pitchShiftSemitones / 12.0);
	
	// Read GUI controls
	int hopSize = (int)gGuiController.getSliderValue(1);
	
	//if hop size changes, recalculate the window based on an overlap factor of 4
	if(hopSize != gHopSize) {
		int newLength = hopSize * 4;
		if(newLength > gFftSize)
			newLength = gFftSize;
		recalculate_window(newLength);
		
		gHopSize = hopSize;
	}
	
	 koji = (int)gGuiController.getSliderValue(gEffectSliderIdx);
	
	for(unsigned int n = 0; n < context->audioFrames; n++) {
        // Read the next sample from the buffer
        float in = audioRead(context, n, 0) + audioRead(context, n, 1) + audioRead(context, n, 2) + audioRead(context, n, 3) + 
        audioRead(context, n, 4) + audioRead(context, n, 5) + audioRead(context, n, 6) + audioRead(context, n, 7);
		// Store the sample ("in") in a buffer for the FFT
		// Increment the pointer and when full window has been 
		// assembled, call process_fft()
		gInputBuffer[gInputBufferPointer++] = in;
		if(gInputBufferPointer >= gBufferSize) {
			// Wrap the circular buffer
			// Notice: this is not the condition for starting a new FFT
			gInputBufferPointer = 0;
		}
		
		// Get the output sample from the output buffer
		float out = gOutputBuffer[gOutputBufferReadPointer];
		
		// Then clear the output sample in the buffer so it is ready for the next overlap-add
		gOutputBuffer[gOutputBufferReadPointer] = 0;
		
		// Scale the output down by the scale factor, compensating for the overlap
		// out *= (float)gHopSize / (float)gFftSize;
		
		// Increment the read pointer in the output cicular buffer
		gOutputBufferReadPointer++;
		if(gOutputBufferReadPointer >= gBufferSize)
			gOutputBufferReadPointer = 0;
		
		// Increment the hop counter and start a new FFT if we've reached the hop size
		if(++gHopCounter >= gHopSize) {
			gHopCounter = 0;
			
			gCachedInputBufferPointer = gInputBufferPointer;
			Bela_scheduleAuxiliaryTask(gFftTask);
		}
		
		// if(++gTestCounter >=gTestInterval) {
		// 	gTestCounter = 0;
			
		// 	if(gInTest){
		// 		rt_printf("Pulse timeout\n");
		// 	}
		// 	gInTest = true;
		// }
		
		// // If we are counting samples, then look for a rising edge above the threshold
		// if(gInTest) {
		// 	if(!gInputAboveThreshold && in >= kInputHiThreshold) {
		// 		// Edge found: stop counting samples	
		// 		gInTest = false;
		// 		gInputAboveThreshold = true;				
				
		// 		int normalisedSamples = gTestCounter - 2*context->audioFrames;
				
		// 		// Print the calculated latency
		// 		rt_printf("Latency: %.2fms (%d samples) --- hardware: %.2fms (%d samples)\n", 
		// 				  1000.0 * gTestCounter / context->audioSampleRate,
		// 				  gTestCounter,
		// 				  1000.0 * normalisedSamples / context->audioSampleRate,
		// 				  normalisedSamples);
		// 	}
			
		// 	// Update the previous input
		// 	gLastInput = in;
		// }
		
		
		// // If the input falls below the lower threshold, set the flag accordingly
		// if(in < kInputLoThreshold) {
		// 	gInputAboveThreshold = false;
		// }

		// Write the audio to the output
		for(unsigned int channel = 0; channel < context->audioOutChannels; channel++) {
			audioWrite(context, n, channel, out);
		}
		
		// Log to the Scope
		gScope.log(in, out);
	}
	
}

void cleanup(BelaContext *context, void *userData)
{

}


