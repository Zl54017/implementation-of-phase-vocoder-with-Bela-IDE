let pitchSlider, hopSizeSlider, effectSlider;

var guiSketch = new p5(function(p) {
    var sampleRate = 44100;

    p.setup = function() {
        p.createCanvas(window.innerWidth, window.innerHeight);
        p.colorMode(p.RGB, 1);
    }

    p.draw = function() {
        // Get the data buffer(s) from the Bela C++ program
        var buffers = Bela.data.buffers;
        
        // Check if any data has been received
        if(!buffers.length)
            return;

        p.background(255); // white background

        var fftSize = buffers[0].length; // This gives the FFT size
        p.strokeWeight(1);
        var zeroDbPos = 0.5;
        var dbRange = 50;
        var freqRange = 1; 
        var freqMin = 0;
        
        // Draw a line for each of the buffers received
        for(let k in buffers) {
            p.noFill();
            var rem = k % 3;
            var color = p.color(0 === rem, 1 === rem, 2 === rem);
            p.stroke(color);
            p.beginShape();
            let buf = buffers[k];
            for (let i = 0; i < fftSize && i < buf.length; i++) {
                var y = (1 / dbRange * (20 * (Math.log10(buf[i])) - zeroDbPos * dbRange) + 1);
                var x = i / (freqRange * fftSize) + freqMin / (sampleRate / 2);
                p.vertex(p.width * x, p.height * (1 - y));
            }
            p.endShape();
        }

        // Draw Y grid
        for(let y = -1; y <= 2; y += 0.1) {
            p.stroke(0, 0, 0, 0.3);
            p.strokeWeight(0.2);
            var yPos = y + zeroDbPos;
            var txt = (-dbRange * yPos + dbRange * zeroDbPos).toFixed(1) + 'dB';
            p.line(0, yPos * p.height, p.width, yPos * p.height);
            p.noStroke();
            p.fill(0);
            p.text(txt, 60, yPos * p.height + 10);
        }

        // Draw X grid
        for(let x = 0.1; x <= 1; x += 0.1) {
            var val = freqRange * (x * sampleRate / 2 - freqMin) / 1000;
            if(val < 0 || val > sampleRate / 2000)
                continue;
            p.stroke(0, 0, 0, 0.3);
            p.strokeWeight(0.2);
            p.line(x * p.width, 0, x * p.width, p.height);
            var txt = val.toFixed(1) + "kHz";
            p.noStroke();
            p.fill(0);
            p.text(txt, x * p.width, 10);
        }
    }

    p.windowResized = function() {
        p.resizeCanvas(window.innerWidth, window.innerHeight);
    }
}, 'gui');

function setup() {
    createCanvas(windowWidth, windowHeight);
    
    // Create and position the sliders
    pitchSlider = createSlider(-12, 12, 0, 0.1);
    pitchSlider.position(10, 10);
    pitchSlider.style('width', '2000px'); // Set width to 2000px

    hopSizeSlider = createSlider(64, 1024, 256, 1);
    hopSizeSlider.position(10, 70); // Adjust position to avoid overlap
    hopSizeSlider.style('width', '2000px'); // Set width to 2000px
    
    effectSlider = createSlider(0, 2, 0, 1);
    effectSlider.position(10, 130); // Adjust position to avoid overlap
    effectSlider.style('width', '2000px'); // Set width to 2000px

    // Attach input handlers
    pitchSlider.input(sendToBela);
    hopSizeSlider.input(sendToBela);
    effectSlider.input(sendToBela);
}

function draw() {
    background(255);
    
    // Display labels for sliders
    textSize(32); // Increase text size for better readability
    fill(0); // Set text color to black for better contrast
    text('Pitch Shift:', 2020, 35); // Adjust label position
    text('Hop Size:', 2020, 95); // Adjust label position
    text('Effect:', 2020, 155); // Adjust label position
    
    // Get slider values
    let pitchValue = pitchSlider.value();
    let hopSizeValue = hopSizeSlider.value();
    let effectValue = effectSlider.value();
    
    // Send slider values to Bela
    Bela.data.sendValue(0, pitchValue);
    Bela.data.sendValue(1, hopSizeValue);
    Bela.data.sendValue(2, effectValue);
}

function sendToBela() {
    // this is the object for which the input has changed
    let value = this.value();
    if (typeof(value) === "string")
        value = parseFloat(value);
    if (isNaN(value)) {
        // this is required for the C++ parser to recognize it as a number (NaN is not recognized as a number)
        value = 0;
    }
    clearTimeout(this.timeout);
    let obj = {};
    obj[this.guiKey] = value;

    // do not send right now: throttle to avoid ultra-fast changes
    this.timeout = setTimeout(function(obj) {
        console.log("Sending ", obj);
        Bela.control.send(obj);
    }.bind(null, obj), 30);
}
